const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

// Define user schema (adjust as needed)
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
  },
}, { timestamps: true });

// Create model
const User = mongoose.models.User || mongoose.model("User", userSchema);

// [GET] /api/users - Get all users
router.get("/", async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch users" });
  }
});

// [POST] /api/users - Create a new user
router.post("/", async (req, res) => {
  try {
    const { name, email } = req.body;
    const newUser = new User({ name, email });
    await newUser.save();
    res.status(201).json(newUser);
  } catch (err) {
    res.status(400).json({ error: "Failed to create user", details: err.message });
  }
});

module.exports = router;
